"""
Student: Asaf Ben Shabat
ID: 312391774
Assignment no. 2
Program: triangle.py
"""
height = int(input("enter height: "))
dollars = int(input("enter dollars: "))
spaces = int(input("enter spaces: "))
Dollars_counter = dollars
Space_counter = 0
for j in range(0, height):          # printing number of row in order to create an array for the triangle
    for i in range(j, height):
        print(" ", end="")
    print("*", end="")
    for i in range(0, j + j - 1):
        if j == height - 1:
            print("*", end="")   # printing the last row
        else:                     # this whole block prints either space or $ by user input request
            if Dollars_counter > 0:
                print("$", end="")
                Dollars_counter -= 1
                if Dollars_counter == 0:
                    Space_counter = spaces
            else:
                print(" ", end="")
                Space_counter -= 1
                if Space_counter == 0:
                    Dollars_counter = dollars
        if i == j + j - 2:
            print("*", end="")

    print()
