"""
Student: Asaf Ben Shabat
ID: 312391774
Assignment no. 2
Program: Sentencesplit.py
"""
sentence = input("please enter a sentence")
for i in sentence.split():  # splits the sentence into a list.
    print(i)
print("There are", len(sentence.split()), "words in:", sentence)