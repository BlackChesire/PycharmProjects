"""
Student: Asaf Ben Shabat
ID: 312391774
Assignment no. 2
Program: decSeries.py
"""
list1 = []
count = 1
max_count = 1
while len(list1) < 10:
    x = int(input("enter number"))
    list1.append(x)
for i in range(len(list1)):
    if list1[i] < list1[i - 1]:  # checking if the next number is smaller
        count += 1  # counting if it does
        if max_count <= count:  # Making max_counter the counter for the longest series of numbers
            max_count = count
    if list1[i] >= list1[i - 1]:  # resting the counter whenever the next number is not smaller
        count = 1

print("the length of the longest series is:", max_count)
