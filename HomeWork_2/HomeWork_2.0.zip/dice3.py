"""
Student: Asaf Ben Shabat
ID: 312391774
Assignment no. 2
Program: dice3.py
"""
from random import randint

n = int(input("Please number of rolls:"))
k = int(input("Please enter amount of same number you would like to reach:"))
roller, target, loop, check1 = 0, 0, 0, 0
while roller < n:
    dice_1, dice_2, dice_3 = randint(1, 6), randint(1, 6), randint(1, 6)  # Defining 3 dices
    roller += 1  # in order to count the rolls
    print(dice_1, dice_2, dice_3)
    if dice_1 == dice_2 == dice_3:
        target += 1  # counting the times all of 3 dices were equal
        if target >= k:
            check1 = loop  # check1 for checking rolls times it took for the target to reach
    loop += 1
if target >= k:  # checking if the target reached
    print("Target reached", k, "equal series after", check1 + 1, "games")
else:
    print("Failed to reach the target only", target, "times")
