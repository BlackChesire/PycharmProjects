"""
Student: Asaf Yosef Ben Shabat
ID: 312391774
Assignment no. 5
Program: RecFuncs.py question number 1
"""


def reversed_string(string):  # prints string backwards
    if len(string) == 0:
        return
    print(string[-1], end="")
    reversed_string(string[:-1])


def count_char(string, char, count=0):  # returns the times the character appears in a string
    if len(string) == 0:
        return count
    if string[0] == char:
        count += 1
    return count_char(string[1:], char, count)


def check_strings(string1, string2):  # returns True if the strings are the same
    if len(string1) == 0 and len(string2) == 0:
        return True
    if len(string2) != len(string1) or string1[0] != string2[0]:
        return False
    if string1[0] == string2[0]:
        return check_strings(string1[1:], string2[1:])


def main():
    string = input("Please enter a string: ")
    print("here is your reversed string:", end=" ")
    reversed_string(string)
    print()
    char = input("enter a character for counting: ")
    print("the number of times that", char, "is on the string is", count_char(string, char))
    string2 = input("enter a string to compare:")
    if check_strings(string, string2) is True:
        print("the strings are the same")
    else:
        print("the strings are not the same")


main()
